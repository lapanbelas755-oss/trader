"""Trader Machine Dashboard Application."""
